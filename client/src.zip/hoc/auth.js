import React , { useEffect } from 'react';  // 라이브러리 에서 가저온다.

import { useDispatch } from 'react-redux';  // 함수  ?
import { auth } from '../_actions/user_action';
//import LandingPage from '../components/views/LandingPage/LandingPage';



export default function (SpecificComponent, option, adminRoute = null){
    // SpecificComponent : LandingPage
    // option
    // null => 아무나 출입이 가능한 페이지
    // true => 로그인한 유저만 출입이 가능한 페이지
    // false =>  로그인한 유저는 출입 불가능한 페이지 
    // adminRoute   기본값 null

    function AuthenticationCheck(props){

        const dispatch = useDispatch();

        useEffect(() => {
            
            //  redux 사용 ,  action 이름  auth()
            dispatch(auth()).then(response =>{

                console.log(response)
                // 분기처리

                // 로기인 하진 않는 상태
                if(!response.payload.isAuth){
                    if(option){
                        props.history.push('/login')
                    }

                }else{ 
                    // 로그인 한 상태
                    if(adminRoute && !response.payload.isAdmin){
                        props.history.push('/')
                    }else{
                        if(option === false)
                            props.history.push('/')
                    }

                }
            })  
            //Axios.get('/api/users/auth')
        
        })  //  },[])

        //Line 48:11:  React Hook useEffect has missing dependencies: 'dispatch' and 'props.history'. 
        // Either include them or remove the dependency array  react-hooks/exhaustive-deps

        return(
            <SpecificComponent />
        )
    }

    return AuthenticationCheck
}