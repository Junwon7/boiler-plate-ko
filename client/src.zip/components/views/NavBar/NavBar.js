import React from 'react'

function NavBar() {
    return (
        <div>
            
        </div>
    )
}

export default NavBar

